# OS Lab 4 - IOScheduler
**C++ version 12 required.**
#### My project has multiple header files and cpp files for modularization and better understanding of classes and global variables.

## Files
1. `iosched.cpp` has the main program that performs operations on the input and provides the output for the schedulers.
2. `globals.cpp` contains all global variables used across the project.

### Run an input file manually
cmd: `make run ALGO='F' OPS='v' FILE='lab4_assign/input1'` 