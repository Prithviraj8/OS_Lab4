//
// Created by Prithviraj Murthy on 04/05/24.
//

#ifndef LAB4_GLOBALS_H
#define LAB4_GLOBALS_H

extern int current_direction;
extern int current_track;
extern int current_time;
extern bool OPTION_V;
extern int total_time;
extern int total_movement;
extern int total_turnaround;
extern int total_wait_time;
extern int max_wait_time;

#endif //LAB4_GLOBALS_H
