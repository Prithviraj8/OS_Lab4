//
// Created by Prithviraj Murthy on 04/05/24.
//
bool OPTION_V = false;

int current_time = 0;
int current_track = 0;
int total_time = 0;
int total_movement = 0;
int current_direction = 1;
bool direction = true;  // true for up, false for down
int total_turnaround = 0;
int total_wait_time = 0;
int max_wait_time = 0;

#include "globals.h"
